package com.example.springboot;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.example.springboot.model.Menu;

public class MenuTest {

    private Menu menu;

    @BeforeEach
    public void setUp() {
        menu = new Menu("Briyani", "21.89", "Delicious Briyani", "Available");
    }

    @Test
    public void testGettersAndSetters() {
        menu.setId(1);
        assertEquals(1, menu.getId());

        menu.setName("Mazza");
        assertEquals("Mazza", menu.getName());

        menu.setItemPrice("12.99");
        assertEquals("12.99", menu.getItemPrice());

        menu.setDescription("Soft Drink");
        assertEquals("Soft Drink", menu.getDescription());
    }

   

  

    @Test
    public void testMenuStatusChange() {
        menu.setStatus("Out of Stock");
        assertEquals("Out of Stock", menu.getStatus());
    }

    

    @Test
    public void testMenuInequality() {
        // Add a test to check if two Menu objects with different attributes are considered not equal
        Menu differentMenu = new Menu("Mazza", "12.99", "Soft Drink", "Out of Stock");
        assertNotEquals(menu, differentMenu);
    }

    

}