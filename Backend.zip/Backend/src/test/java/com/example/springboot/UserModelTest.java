// UserModelTest.java
package com.example.springboot;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.example.springboot.model.UserModel;

public class UserModelTest {

    private UserModel user;

    @BeforeEach
    public void setUp() {
        user = new UserModel();
        user.setName("Anurag");
        user.setEmail("anurag@gmail.com");
        user.setMobile("1234567890");
        user.setAddress("123 Setup");
        user.setUsername("anurag");
        user.setPassword("Anurag12@");
    }

    @Test
    public void testGettersAndSetters() {
        user.setId(1);
        assertEquals(1, user.getId());

        assertEquals("Anurag", user.getName());
        assertEquals("anurag@gmail.com", user.getEmail());
        assertEquals("1234567890", user.getMobile());
        assertEquals("123 Setup", user.getAddress());
        assertEquals("anurag", user.getUsername());
        assertEquals("Anurag12@", user.getPassword());

        // Additional setters and getters test
        user.setName("Devendra");
        assertEquals("Devendra", user.getName());

        user.setEmail("devendra@yahoo.com");
        assertEquals("devendra@yahoo.com", user.getEmail());

        user.setMobile("9876543210");
        assertEquals("9876543210", user.getMobile());

        user.setAddress("Barcelona");
        assertEquals("Barcelona", user.getAddress());

        user.setUsername("devendra");
        assertEquals("devendra", user.getUsername());

        user.setPassword("devendra12@");
        assertEquals("devendra12@", user.getPassword());
    }

    @Test
    public void testNonEquality() {
        // Add a test to check if two UserModel objects with different attributes are considered not equal
        UserModel differentUser = new UserModel();
        differentUser.setName("Devendra");
        differentUser.setEmail("devendra@example.com");
        differentUser.setMobile("9876543210");
        differentUser.setAddress("Barcelona");
        differentUser.setUsername("devendra");
        differentUser.setPassword("devendra12@");

        assertNotEquals(user, differentUser);
    }

    @Test
    public void testDefaultValues() {
        // Add a test to check default values when no values are set
        UserModel defaultUser = new UserModel();
        assertEquals(0, defaultUser.getId());
        assertNull(defaultUser.getName());
        assertNull(defaultUser.getEmail());
        assertNull(defaultUser.getMobile());
        assertNull(defaultUser.getAddress());
        assertNull(defaultUser.getUsername());
        assertNull(defaultUser.getPassword());
    }

    @Test
    public void testHashcodeConsistency() {
        // Add a test to check if hashcode remains consistent
        int initialHashcode = user.hashCode();
        assertEquals(initialHashcode, user.hashCode());
    }

    @Test
    public void testHashcodeNonEquality() {
        // Add a test to check hashcode non-equality for two objects with different attributes
        UserModel differentUser = new UserModel();
        differentUser.setName("Devendra");
        differentUser.setEmail("devendra@example.com");
        differentUser.setMobile("9876543210");
        differentUser.setAddress("Porto Rico");
        differentUser.setUsername("devendrad");
        differentUser.setPassword("devendra12@");

        assertNotEquals(user.hashCode(), differentUser.hashCode());
    }

    

}