package com.example.springboot;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.example.springboot.model.TableModel;

public class TableModelTest {

    private TableModel table;

    @BeforeEach
    public void setUp() {
        table = new TableModel();
        table.setId(1);
        table.setTablerow("A");
        table.setTablenumber("1");
        table.setTablecapacity("4");
        table.setTabletype("Square");
    }

    @Test
    public void testGettersAndSetters() {
        assertEquals(1, table.getId());

        assertEquals("A", table.getTablerow());
        table.setTablerow("B");
        assertEquals("B", table.getTablerow());

        assertEquals("1", table.getTablenumber());
        table.setTablenumber("2");
        assertEquals("2", table.getTablenumber());

        assertEquals("4", table.getTablecapacity());
        table.setTablecapacity("6");
        assertEquals("6", table.getTablecapacity());

        assertEquals("Square", table.getTabletype());
        table.setTabletype("Round");
        assertEquals("Round", table.getTabletype());
    }

    

    @Test
    public void testDefaultValues() {
        TableModel defaultTable = new TableModel();
        assertEquals(0, defaultTable.getId());
        assertEquals(null, defaultTable.getTablerow());
        assertEquals(null, defaultTable.getTablenumber());
        assertEquals(null, defaultTable.getTablecapacity());
        assertEquals(null, defaultTable.getTabletype());
    }

   

    @Test
    public void testInequality() {
        TableModel differentTable = new TableModel();
        differentTable.setId(2);
        differentTable.setTablerow("C");
        differentTable.setTablenumber("3");
        differentTable.setTablecapacity("8");
        differentTable.setTabletype("Rectangle");
        assertNotEquals(table, differentTable);
    }

   

    @Test
    public void testHashCodeInequality() {
        TableModel differentTable = new TableModel();
        differentTable.setId(2);
        differentTable.setTablerow("C");
        differentTable.setTablenumber("3");
        differentTable.setTablecapacity("8");
        differentTable.setTabletype("Rectangle");
        assertNotEquals(table.hashCode(), differentTable.hashCode());
    }

    @Test
    public void testNullEquality() {
        assertNotEquals(table, null);
    }

    @Test
    public void testDifferentClassEquality() {
        assertNotEquals(table, "Not a TableModel");
    }
}